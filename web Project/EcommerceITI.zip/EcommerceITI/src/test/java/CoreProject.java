import net.bytebuddy.build.Plugin;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.PriorityQueue;

public class CoreProject {
    //WebDriver driver = null;
    WebDriver driver = new ChromeDriver();
    SoftAssert soft =new SoftAssert();
    @BeforeTest
    public void openBrowser() throws InterruptedException {
        //1 connect to browser
        System.setProperty(" webdriver.chrome.driver ", " E:\\Java\\EcommerceITI\\src\\main\\resources\\chromedriver.exe ");

        //driver.navigate().to("https://automationexercise.com/");
        driver.manage().window().maximize();
        Thread.sleep(3000);
    }
    @Test (priority = 1)
    public void RegistrationInvalid() throws InterruptedException {
        driver.navigate().to("https://automationexercise.com/");
        //4 registration to the e-commerce website by skipping mandatory fields
        driver.findElement(By.linkText("Signup / Login")).click();
        driver.findElement(By.name("name")).click();
        driver.findElement(By.name("name")).sendKeys("Hagar");
        driver.findElement(By.cssSelector("input[data-qa=\"signup-email\"]")).click();
        driver.findElement(By.cssSelector("input[data-qa=\"signup-email\"]")).sendKeys("hagarhecham12@gmail.com");
        driver.findElement(By.cssSelector("button[data-qa=\"signup-button\"]")).click();
        driver.findElement(By.id("id_gender2")).click();
        driver.findElement(By.cssSelector("input[data-qa=\"password\"]")).sendKeys("0123456789");
        driver.findElement(By.id("first_name")).sendKeys("Hagar");
        driver.findElement(By.id("last_name")).sendKeys("Hecham");
        driver.findElement(By.id("country")).click();
        driver.findElement(By.cssSelector("option[value=\"United States\"]")).click();
        driver.findElement(By.id("state")).sendKeys("New York");
        driver.findElement(By.id("city")).sendKeys("New York");
        driver.findElement(By.id("zipcode")).sendKeys("10001");
        driver.findElement(By.id("mobile_number")).sendKeys("01300138300");
        driver.findElement(By.cssSelector("button[data-qa=\"create-account\"]")).click();
        String popupMsg = driver.findElement(By.id("address1")).getText();
        System.out.println(popupMsg);
        Thread.sleep(2000);
    }
    @Test (priority = 2)
    public void RegistrationValid () throws InterruptedException {
        driver.navigate().to("https://automationexercise.com/");
        //4 registration to the e-commerce website
        driver.findElement(By.linkText("Signup / Login")).click();
        driver.findElement(By.name("name")).click();
        driver.findElement(By.name("name")).sendKeys("Hagar");
        driver.findElement(By.cssSelector("input[data-qa=\"signup-email\"]")).click();
        driver.findElement(By.cssSelector("input[data-qa=\"signup-email\"]")).sendKeys("hagarhecham12@gmail.com");
        driver.findElement(By.cssSelector("button[data-qa=\"signup-button\"]")).click();

        driver.findElement(By.id("id_gender2")).click();
        driver.findElement(By.cssSelector("input[data-qa=\"password\"]")).sendKeys("0123456789");

        driver.findElement(By.id("days")).click();
        driver.findElement(By.cssSelector("option[value=\"14\"]")).click();
        driver.findElement(By.id("months")).click();
        driver.findElement(By.cssSelector("option[value=\"7\"]")).click();
        driver.findElement(By.id("years")).click();
        driver.findElement(By.cssSelector("option[value=\"1996\"]")).click();

        driver.findElement(By.id("first_name")).sendKeys("Hagar");
        driver.findElement(By.id("last_name")).sendKeys("Hecham");
        driver.findElement(By.id("address1")).sendKeys("Gleem");
        driver.findElement(By.id("country")).click();
        driver.findElement(By.cssSelector("option[value=\"United States\"]")).click();
        driver.findElement(By.id("state")).sendKeys("New York");
        driver.findElement(By.id("city")).sendKeys("New York");
        driver.findElement(By.id("zipcode")).sendKeys("10001");
        driver.findElement(By.id("mobile_number")).sendKeys("01300138300");
        driver.findElement(By.cssSelector("button[data-qa=\"create-account\"]")).click();
        String successMsg = driver.findElement(By.cssSelector("div[class=\"row\"]")).getText();
        System.out.println(successMsg);
        driver.findElement(By.cssSelector("a[data-qa=\"continue-button\"]")).click();
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("a[href=\"/logout\"]")).click();
        Thread.sleep(2000);

    }


    @Test (priority = 3)
    public void LoginInvalid() throws InterruptedException {
        driver.navigate().to("https://automationexercise.com/login");
        driver.findElement(By.cssSelector("input[data-qa=\"login-email\"]")).sendKeys("hagarhecham12@gmail.com");
        driver.findElement(By.cssSelector("input[data-qa=\"login-password\"]")).sendKeys("012345");
        driver.findElement(By.cssSelector("input[data-qa=\"login-password\"]")).sendKeys(Keys.ENTER);
        String expectedResult = "Your email or password is incorrect!";
        String actualResult = driver.findElement(By.cssSelector("p[style=\"color: red;\"]")).getText();
        soft.assertTrue(actualResult.contains(expectedResult));
    }

    @Test (priority = 4)
    public void LoginValid ()
    {
        driver.navigate().to("https://automationexercise.com/login");
        driver.findElement(By.cssSelector("input[data-qa=\"login-email\"]")).sendKeys("hagarhecham12@gmail.com");
        driver.findElement(By.cssSelector("input[data-qa=\"login-password\"]")).sendKeys("0123456789");
        driver.findElement(By.cssSelector("input[data-qa=\"login-password\"]")).sendKeys(Keys.ENTER);
    }


    @AfterTest
    public void closeBrowser() throws InterruptedException
    {
        Thread.sleep(3000);

        //6 close the browser
        driver.quit();
    }
}
